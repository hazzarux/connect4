public class Leeg extends Schijf {
	public Leeg() {
		super.setCharacter("_");
	}
}
