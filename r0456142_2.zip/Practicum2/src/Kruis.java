public class Kruis extends Schijf {
	public Kruis() {
		super.setCharacter("X");
	}

}
