public class Aambeeld extends Schijf {
	public Aambeeld() {
		super.setCharacter("#");
	}
}
