public class Muurschijf extends Schijf {
	public Muurschijf() {
		super.setCharacter("%");
	}
}
