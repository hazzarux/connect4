public class Rondje extends Schijf {
	public Rondje() {
		super.setCharacter("O");
	}
}
